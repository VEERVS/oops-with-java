package com.example.Student.model;

public class Student {
    
}
